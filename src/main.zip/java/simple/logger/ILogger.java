package simple.logger;

public interface ILogger {
    void add(String message);
    void add(char message);
    void print();
}
