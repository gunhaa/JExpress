package simple.middleware;

public interface IMiddleWare {
    void run();
}
