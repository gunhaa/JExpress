package simple.middleware;

public class GetCache {
}
