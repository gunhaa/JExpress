package simple.mapper;

import simple.constant.CustomHttpMethod;
import simple.httpRequest.HttpRequest;
import simple.httpResponse.ILambdaHandlerWrapper;
import simple.httpResponse.LambdaHandlerWrapper;
import simple.url.PostUrlRouterTrie;

import java.util.HashMap;
import java.util.Map;

public class PostMapper implements IMapper{

    private static final IMapper POST_MAPPER = new PostMapper();
    private final HashMap<String, LambdaHandlerWrapper> postMap;
    private final PostUrlRouterTrie postUrlRouterTrie;
    private final CustomHttpMethod customHttpMethod;

    private PostMapper(){
        this.customHttpMethod=CustomHttpMethod.POST;
        this.postMap = new HashMap<>();
        this.postUrlRouterTrie = PostUrlRouterTrie.getInstance();
    }

    public static IMapper getInstance(){
        return POST_MAPPER;
    }

    @Override
    public CustomHttpMethod getMethod() {
        return this.customHttpMethod;
    }

    @Override
    public ILambdaHandlerWrapper getLambdaHandler(HttpRequest httpRequest) {
        return null;
    }

    @Override
    public Map<String, LambdaHandlerWrapper> getHandlers() {
        return Map.of();
    }

    @Override
    public void addUrl(String URL, ILambdaHandlerWrapper ILambdaHandlerWrapper) {

    }

    @Override
    public void addUrl(String URL, ILambdaHandlerWrapper ILambdaHandlerWrapper, Class<?> clazz) {

    }
}
